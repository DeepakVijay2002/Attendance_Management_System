-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2023 at 07:24 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendancemsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `Id` int(10) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `emailAddress` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`Id`, `firstName`, `lastName`, `emailAddress`, `password`) VALUES
(1, 'Deepak', 'vijay', '20csc112@aactni.edu.in', 'D00F5D5217896FB7FD601412CB890830'),
(3, '[deepak]', '[vijay]', '[20csc112@aactni.edu.in]', '[D00F5D5217896FB7FD601412CB890830]');

-- --------------------------------------------------------

--
-- Table structure for table `tblattendance`
--

CREATE TABLE `tblattendance` (
  `Id` int(10) NOT NULL,
  `admissionNo` varchar(255) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `sessionTermId` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `dateTimeTaken` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblattendance`
--

INSERT INTO `tblattendance` (`Id`, `admissionNo`, `classId`, `classArmId`, `sessionTermId`, `status`, `dateTimeTaken`) VALUES
(162, 'ASDFLKJ', '1', '2', '1', '1', '2020-11-01'),
(163, 'HSKSDD', '1', '2', '1', '1', '2020-11-01'),
(164, 'JSLDKJ', '1', '2', '1', '1', '2020-11-01'),
(172, 'HSKDS9EE', '1', '4', '1', '1', '2020-11-01'),
(171, 'JKADA', '1', '4', '1', '0', '2020-11-01'),
(170, 'JSFSKDJ', '1', '4', '1', '1', '2020-11-01'),
(173, 'ASDFLKJ', '1', '2', '1', '1', '2020-11-19'),
(174, 'HSKSDD', '1', '2', '1', '1', '2020-11-19'),
(175, 'JSLDKJ', '1', '2', '1', '1', '2020-11-19'),
(176, 'JSFSKDJ', '1', '4', '1', '0', '2021-07-15'),
(177, 'JKADA', '1', '4', '1', '0', '2021-07-15'),
(178, 'HSKDS9EE', '1', '4', '1', '0', '2021-07-15'),
(179, 'ASDFLKJ', '1', '2', '1', '0', '2021-09-27'),
(180, 'HSKSDD', '1', '2', '1', '1', '2021-09-27'),
(181, 'JSLDKJ', '1', '2', '1', '1', '2021-09-27'),
(182, 'ASDFLKJ', '1', '2', '1', '0', '2021-10-06'),
(183, 'HSKSDD', '1', '2', '1', '0', '2021-10-06'),
(184, 'JSLDKJ', '1', '2', '1', '1', '2021-10-06'),
(185, 'ASDFLKJ', '1', '2', '1', '0', '2021-10-07'),
(186, 'HSKSDD', '1', '2', '1', '0', '2021-10-07'),
(187, 'JSLDKJ', '1', '2', '1', '0', '2021-10-07'),
(188, 'AMS110', '4', '6', '1', '0', '2021-10-07'),
(189, 'AMS133', '4', '6', '1', '0', '2021-10-07'),
(190, 'AMS135', '4', '6', '1', '0', '2021-10-07'),
(191, 'AMS144', '4', '6', '1', '0', '2021-10-07'),
(192, 'AMS148', '4', '6', '1', '0', '2021-10-07'),
(193, 'AMS151', '4', '6', '1', '0', '2021-10-07'),
(194, 'AMS159', '4', '6', '1', '0', '2021-10-07'),
(195, 'AMS161', '4', '6', '1', '0', '2021-10-07'),
(196, 'AMS110', '4', '6', '1', '0', '2023-03-01'),
(197, 'AMS133', '4', '6', '1', '0', '2023-03-01'),
(198, 'AMS135', '4', '6', '1', '0', '2023-03-01'),
(199, 'AMS144', '4', '6', '1', '0', '2023-03-01'),
(200, 'AMS148', '4', '6', '1', '0', '2023-03-01'),
(201, 'AMS151', '4', '6', '1', '0', '2023-03-01'),
(202, 'AMS159', '4', '6', '1', '0', '2023-03-01'),
(203, 'AMS161', '4', '6', '1', '0', '2023-03-01'),
(204, 'AMS110', '4', '6', '1', '0', '2023-03-02'),
(205, 'AMS133', '4', '6', '1', '0', '2023-03-02'),
(206, 'AMS135', '4', '6', '1', '0', '2023-03-02'),
(207, 'AMS144', '4', '6', '1', '0', '2023-03-02'),
(208, 'AMS148', '4', '6', '1', '0', '2023-03-02'),
(209, 'AMS151', '4', '6', '1', '0', '2023-03-02'),
(210, 'AMS159', '4', '6', '1', '0', '2023-03-02'),
(211, 'AMS161', '4', '6', '1', '0', '2023-03-02'),
(212, '22csc118', '5', '8', '', '1', '2023-03-02'),
(213, '22csc137', '5', '8', '', '1', '2023-03-02'),
(214, '22csc160', '5', '8', '', '1', '2023-03-02'),
(215, '22csc118', '5', '8', '5', '1', '2023-03-04'),
(216, '22csc137', '5', '8', '5', '1', '2023-03-04'),
(217, '22csc160', '5', '8', '5', '1', '2023-03-04'),
(218, '20csc112', '3', '5', '5', '1', '2023-03-04'),
(219, '20csc164', '3', '5', '5', '1', '2023-03-04'),
(220, 'AMS019', '3', '5', '5', '1', '2023-03-04'),
(221, 'AMS021', '3', '5', '5', '0', '2023-03-04'),
(222, 'AMS012', '1', '4', '5', '0', '2023-03-04'),
(223, 'AMS015', '1', '4', '5', '0', '2023-03-04'),
(224, 'AMS017', '1', '4', '5', '0', '2023-03-04'),
(225, '20csc141', '1', '4', '5', '1', '2023-03-04'),
(226, '20csc112', '7', '11', '5', '1', '2023-03-04'),
(227, '20csc164', '7', '11', '5', '1', '2023-03-04'),
(228, '22csc118', '5', '8', '5', '1', '2023-03-07'),
(229, '22csc137', '5', '8', '5', '1', '2023-03-07'),
(230, '22csc160', '5', '8', '5', '1', '2023-03-07'),
(231, '21csc122', '6', '10', '5', '1', '2023-03-07'),
(232, '21csc138', '6', '10', '5', '1', '2023-03-07'),
(233, '21csc109', '6', '10', '5', '1', '2023-03-07'),
(234, '21csc115', '6', '10', '5', '1', '2023-03-07'),
(235, '21csc140', '6', '10', '5', '1', '2023-03-07'),
(236, '21csc126', '6', '10', '5', '1', '2023-03-07'),
(237, '21csc122', '6', '10', '5', '1', '2023-03-08'),
(238, '21csc138', '6', '10', '5', '1', '2023-03-08'),
(239, '21csc109', '6', '10', '5', '1', '2023-03-08'),
(240, '21csc115', '6', '10', '5', '1', '2023-03-08'),
(241, '21csc140', '6', '10', '5', '1', '2023-03-08'),
(242, '21csc126', '6', '10', '5', '1', '2023-03-08'),
(243, '20csc112', '7', '11', '5', '1', '2023-03-08'),
(244, '20csc164', '7', '11', '5', '1', '2023-03-08'),
(245, '20csc112', '7', '15', '5', '1', '2023-03-08'),
(246, '20csc164', '7', '15', '5', '1', '2023-03-08'),
(247, '20csc141', '7', '15', '5', '1', '2023-03-08'),
(248, '20csc123', '7', '15', '5', '1', '2023-03-08'),
(249, '20csc133', '7', '15', '5', '1', '2023-03-08'),
(250, '20csc109', '7', '15', '5', '1', '2023-03-08'),
(251, '22csc118', '5', '8', '7', '1', '2023-03-08'),
(252, '22csc137', '5', '8', '7', '1', '2023-03-08'),
(253, '22csc160', '5', '8', '7', '1', '2023-03-08'),
(254, '22csc118', '5', '8', '7', '1', '2023-03-09'),
(255, '22csc137', '5', '8', '7', '1', '2023-03-09'),
(256, '22csc160', '5', '8', '7', '1', '2023-03-09'),
(257, '20csc112', '7', '15', '7', '1', '2023-03-09'),
(258, '20csc164', '7', '15', '7', '1', '2023-03-09'),
(259, '20csc141', '7', '15', '7', '1', '2023-03-09'),
(260, '20csc123', '7', '15', '7', '1', '2023-03-09'),
(261, '20csc133', '7', '15', '7', '1', '2023-03-09'),
(262, '20csc109', '7', '15', '7', '1', '2023-03-09'),
(263, '20csc112', '7', '11', '7', '1', '2023-03-09'),
(264, '20csc141', '7', '11', '7', '1', '2023-03-09'),
(265, '20csc123', '7', '11', '7', '1', '2023-03-09'),
(266, '21csc115', '6', '10', '7', '1', '2023-03-09'),
(267, '21csc140', '6', '10', '7', '1', '2023-03-09'),
(268, '21csc126', '6', '10', '7', '1', '2023-03-09'),
(269, '20csc164', '7', '15', '8', '1', '2023-03-12'),
(270, '20csc133', '7', '15', '8', '0', '2023-03-12'),
(271, '20csc109', '7', '15', '8', '1', '2023-03-12'),
(272, '20csc112', '7', '11', '8', '1', '2023-03-12'),
(273, '20csc141', '7', '11', '8', '1', '2023-03-12'),
(274, '20csc123', '7', '11', '8', '1', '2023-03-12'),
(275, '22csc118', '5', '8', '4', '1', '2023-03-12'),
(276, '22csc137', '5', '8', '4', '1', '2023-03-12'),
(277, '22csc160', '5', '8', '4', '1', '2023-03-12'),
(278, '21csc115', '6', '10', '4', '1', '2023-03-12'),
(279, '21csc140', '6', '10', '4', '1', '2023-03-12'),
(280, '21csc126', '6', '10', '4', '0', '2023-03-12'),
(281, '22csc118', '5', '8', '8', '1', '2023-03-13'),
(282, '22csc137', '5', '8', '8', '1', '2023-03-13'),
(283, '22csc160', '5', '8', '8', '1', '2023-03-13'),
(284, '20csc112', '7', '11', '8', '0', '2023-03-13'),
(285, '20csc141', '7', '11', '8', '0', '2023-03-13'),
(286, '20csc123', '7', '11', '8', '0', '2023-03-13'),
(287, '20csc164', '7', '15', '8', '1', '2023-03-13'),
(288, '20csc133', '7', '15', '8', '0', '2023-03-13'),
(289, '20csc109', '7', '15', '8', '1', '2023-03-13'),
(290, '21csc122', '6', '9', '5', '1', '2023-03-13'),
(291, '21csc138', '6', '9', '5', '1', '2023-03-13'),
(292, '21csc109', '6', '9', '5', '1', '2023-03-13'),
(293, '22csc118', '5', '8', '10', '1', '2023-04-02'),
(294, '22csc137', '5', '8', '10', '1', '2023-04-02'),
(295, '22csc160', '5', '8', '10', '1', '2023-04-02'),
(296, '22csc118', '5', '8', '10', '1', '2023-04-11'),
(297, '22csc137', '5', '8', '10', '1', '2023-04-11'),
(298, '22csc160', '5', '8', '10', '1', '2023-04-11'),
(299, '21csc122', '6', '9', '10', '1', '2023-04-11'),
(300, '21csc138', '6', '9', '10', '1', '2023-04-11'),
(301, '21csc109', '6', '9', '10', '0', '2023-04-11'),
(302, '22csc118', '5', '8', '10', '1', '2023-04-12'),
(303, '22csc137', '5', '8', '10', '1', '2023-04-12'),
(304, '22csc160', '5', '8', '10', '1', '2023-04-12'),
(305, '22csc118', '5', '8', '10', '1', '2023-04-13'),
(306, '22csc137', '5', '8', '10', '1', '2023-04-13'),
(307, '22csc160', '5', '8', '10', '0', '2023-04-13');

-- --------------------------------------------------------

--
-- Table structure for table `tblclass`
--

CREATE TABLE `tblclass` (
  `Id` int(10) NOT NULL,
  `className` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclass`
--

INSERT INTO `tblclass` (`Id`, `className`) VALUES
(9, '2nd mca'),
(8, '1st mca'),
(5, '1st CSC'),
(6, '2nd CSC'),
(7, '3rd CSC');

-- --------------------------------------------------------

--
-- Table structure for table `tblclassarms`
--

CREATE TABLE `tblclassarms` (
  `Id` int(10) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmName` varchar(255) NOT NULL,
  `isAssigned` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclassarms`
--

INSERT INTO `tblclassarms` (`Id`, `classId`, `classArmName`, `isAssigned`) VALUES
(10, '6', '4th sem', '1'),
(9, '6', '3rd sem', '1'),
(18, '9', '3rd sem', '0'),
(17, '8', '1st sem', '0'),
(7, '5', '1st  sem', '0'),
(8, '5', '2nd sem', '1'),
(11, '7', '5th sem', '1'),
(15, '7', '6th sem', '1'),
(16, '8', '2nd sem', '0'),
(19, '9', '4th sem', '0'),
(20, '8', '6th sem', '0'),
(21, '9', '5th sem', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tblclassteacher`
--

CREATE TABLE `tblclassteacher` (
  `Id` int(10) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `emailAddress` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phoneNo` varchar(50) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `dateCreated` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclassteacher`
--

INSERT INTO `tblclassteacher` (`Id`, `firstName`, `lastName`, `emailAddress`, `password`, `phoneNo`, `classId`, `classArmId`, `dateCreated`) VALUES
(15, 'justin', 'kennedy', 'justinkennedy@gmail.com', '32250170a0dca92d53ec9624f336ca24', '09944121331', '6', '9', '2023-03-13'),
(7, 'vijaya', 'kumar', 'vijayakumar@mail.com', '32250170a0dca92d53ec9624f336ca24', '9500039902', '7', '12', '2023-03-02'),
(8, 'juliet', 'shanthi', 'julietshanthi@aactni.edu.in', '32250170a0dca92d53ec9624f336ca24', '9944121331', '5', '8', '2023-03-02'),
(14, 'manoj', 'prabhakaran', 'manojprabhakaran@aactni.edu.in', '32250170a0dca92d53ec9624f336ca24', '09944121331', '7', '15', '2023-03-08'),
(10, 'Charles', 'ilayaraja', 'charlesilayaraja@aactni.edu.in', '32250170a0dca92d53ec9624f336ca24', '9894561674', '7', '11', '2023-03-04'),
(13, 'Rani', '.V', 'rani@aactni.edu.in', '32250170a0dca92d53ec9624f336ca24', '07646237878', '6', '10', '2023-03-07');

-- --------------------------------------------------------

--
-- Table structure for table `tblsessionterm`
--

CREATE TABLE `tblsessionterm` (
  `Id` int(10) NOT NULL,
  `sessionName` varchar(50) NOT NULL,
  `termId` varchar(50) NOT NULL,
  `isActive` varchar(10) NOT NULL,
  `dateCreated` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsessionterm`
--

INSERT INTO `tblsessionterm` (`Id`, `sessionName`, `termId`, `isActive`, `dateCreated`) VALUES
(7, 'java', '1', '0', '2023-03-04'),
(6, 'MAD', '3', '0', '2023-03-04'),
(4, 'c++', '1', '0', '2023-03-02'),
(5, 'CN', '2', '0', '2023-03-04'),
(8, 'RDBMS', '2', '0', '2023-03-07'),
(9, 'SE', '2', '0', '2023-03-08'),
(10, 'dotnet', '1', '1', '2023-03-13');

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

CREATE TABLE `tblstudents` (
  `Id` int(10) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `otherName` varchar(255) NOT NULL,
  `admissionNumber` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `dateCreated` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`Id`, `firstName`, `lastName`, `otherName`, `admissionNumber`, `password`, `classId`, `classArmId`, `dateCreated`) VALUES
(1, 'deepak', 'vijay', '', '20csc112', '12345', '7', '11', '2020-10-31'),
(3, 'wilson', 'victor', '', '20csc164', '12345', '7', '15', '2020-10-31'),
(4, 'Milagros', 'Lawson', 'none', 'AMS011', '12345', '1', '2', '2020-10-31'),
(5, 'Luis', 'Ayo', 'none', 'AMS012', '12345', '1', '4', '2020-10-31'),
(6, 'Sandra', 'Salgado', 'none', 'AMS015', '12345', '1', '4', '2020-10-31'),
(7, 'Smith', 'Mack', 'Mack', 'AMS017', '12345', '1', '4', '2020-10-31'),
(8, 'Juliana', 'Debiie', 'none', 'AMS019', '12345', '3', '5', '2020-10-31'),
(9, 'Richard', 'Grimmer', 'none', 'AMS021', '12345', '3', '5', '2020-10-31'),
(10, 'Jon', 'Boller', 'none', 'AMS110', '12345', '4', '6', '2021-10-07'),
(11, 'Aida', 'Hawley', 'none', 'AMS133', '12345', '4', '6', '2021-10-07'),
(12, 'Miguel', 'Bush', 'none', 'AMS135', '12345', '4', '6', '2021-10-07'),
(13, 'Sergio', 'Hammons', 'none', 'AMS144', '12345', '4', '6', '2021-10-07'),
(14, 'Lyn', 'Rogers', 'none', 'AMS148', '12345', '4', '6', '2021-10-07'),
(15, 'James', 'Dominick', 'none', 'AMS151', '12345', '4', '6', '2021-10-07'),
(16, 'Ethel', 'Quin', 'none', 'AMS159', '12345', '4', '6', '2021-10-07'),
(17, 'Roland', 'Estrada', 'none', 'AMS161', '12345', '4', '6', '2021-10-07'),
(32, 'Pari', 'Kabilan.V', '', '20csc141', '12345', '7', '11', '2023-03-08'),
(19, 'harish', 'susai', 'c++', '22csc118', '12345', '5', '8', '2023-03-02'),
(20, 'ruban', 'roy', '', '22csc137', '12345', '5', '8', '2023-03-02'),
(21, 'zenith', 'zenith', '', '22csc160', '12345', '5', '8', '2023-03-02'),
(23, 'kali', 'doss', '', '21csc122', '12345', '6', '9', '2023-03-07'),
(24, 'Rahul', 'nandha', '', '21csc138', '12345', '6', '9', '2023-03-07'),
(25, 'Barani', 'dharan', '', '21csc109', '12345', '6', '9', '2023-03-07'),
(26, 'Hari Anandha', 'Kumar', '', '21csc115', '12345', '6', '10', '2023-03-07'),
(27, 'Santhosh', 'kumar', '', '21csc140', '12345', '6', '10', '2023-03-07'),
(28, 'Libertin', 'Lijoe', '', '21csc126', '12345', '6', '10', '2023-03-07'),
(29, 'Jenis', '. X', '', '20csc123', '12345', '7', '11', '2023-03-08'),
(30, 'Mathew', '.A', '', '20csc133', '12345', '7', '15', '2023-03-08'),
(31, 'Basteen', 'Santhiyagu', '', '20csc109', '12345', '7', '15', '2023-03-08');

-- --------------------------------------------------------

--
-- Table structure for table `tblterm`
--

CREATE TABLE `tblterm` (
  `Id` int(10) NOT NULL,
  `termName` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblterm`
--

INSERT INTO `tblterm` (`Id`, `termName`) VALUES
(1, 'odd'),
(2, 'even');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblattendance`
--
ALTER TABLE `tblattendance`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblclass`
--
ALTER TABLE `tblclass`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblclassarms`
--
ALTER TABLE `tblclassarms`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblclassteacher`
--
ALTER TABLE `tblclassteacher`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblsessionterm`
--
ALTER TABLE `tblsessionterm`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblterm`
--
ALTER TABLE `tblterm`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblattendance`
--
ALTER TABLE `tblattendance`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=308;

--
-- AUTO_INCREMENT for table `tblclass`
--
ALTER TABLE `tblclass`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblclassarms`
--
ALTER TABLE `tblclassarms`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblclassteacher`
--
ALTER TABLE `tblclassteacher`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblsessionterm`
--
ALTER TABLE `tblsessionterm`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tblterm`
--
ALTER TABLE `tblterm`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
